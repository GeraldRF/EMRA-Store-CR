<!--- http://localhost:3000 | <n?php echo $server; ?> -->
<?php $server = "https://grfixurdivice.000webhostapp.com"; ?>

<head>
  <link rel="stylesheet" href="<?php echo $server; ?>/recursos/estilos-css/menu.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</head>

<nav class="navbar navbar-expand-sm navbar-toggleable-sm navbar-light bg-lsg border-bottom box-shadow mb-3" id="#nav-main">
  <div class="container" style="max-width:100vw">
    <div>
      <!--- EMRA-Store-CR-Logo.png -->
      <img src="<?php echo $server; ?>/recursos/imagenes/img-ui/Logo.png" style="margin-right:90px; max-width:220px; max-height:70px;">
    </div>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="navbar-collapse collapse d-sm-inline-flex justify-content-between" id="collapseExample">
      <ul class="navbar-nav flex-grow-1">

        <li class="nav-item col-ms-3">
          <a class="nav-link btn-menu" href="<?php echo $server; ?>"><img src="<?php echo $server; ?>/recursos/imagenes/img-ui/inicio.png" style="max-width: 50px;">
           <?php if(isset($_POST['width'])>400){echo "<p style=\"display: block;\"><strong>Inicio</strong></p>"; }else {echo "<p><strong>Inicio</strong></p>"; } ?> 
          </a>
        </li>
        <li class="nav-item col-ms-3">
          <a class="nav-link btn-menu" href="<?php echo $server; ?>"><img src="<?php echo $server; ?>/recursos/imagenes/img-ui/destacados.png" style="max-width: 50px;">
            <p><strong>Destacado</strong></p>
          </a>
        </li>
        <li class="nav-item ">
          <a class="nav-link btn-menu" href="<?php echo $server; ?>"><img src="<?php echo $server; ?>/recursos/imagenes/img-ui/Carrito.png" style="max-width: 50px;">
            <p><strong>Carrito</strong></p>
          </a>
        </li>
        <li class="nav-item ">
          <a class="nav-link btn-menu" href="<?php echo $server; ?>"><img src="<?php echo $server; ?>/recursos/imagenes/img-ui/favoritos.png" style="max-width: 50px;">
            <p><strong>Favoritos</strong></p>
          </a>
        </li>

      </ul>
    </div>

      <div class="container col-md-auto contenedor-busqueda">
        <img src="<?php echo $server; ?>/recursos/imagenes/img-ui/lupa.png" style="max-width: 30px; margin:4px"><input type="text" placeholder="¿Qué buscas?" style="border: none; outline:none">
      </div>

    <div class="navbar-collapse collapse d-sm-inline-flex justify-content-between" id="collapseExample" style="text-align: center;"> 
      <div class="flex-grow-1 col-lg-auto row" style="align-content: center; align-items: center; ">
        <div class="col-md-auto">
          <!--- <img src="< ?php echo $server; ?>/recursos/imagenes/img_ui/persona.ico" style="vertical-align:middle; max-width:50px;"> -->
          <a class="btn btn-iniciar-sesion " href="<?php echo $server; ?>/ui/inicia-sesion"><strong>Iniciar sesion</strong></a>
        </div>
        <div class="col-md-auto">
          <a class="btn btn-registrar " href="<?php echo $server; ?>/ui/registrarse"><strong>Registrate</strong></a>
        </div>
      </div>
    </div>
  </div>
</nav>

